package com.delfood.delfood.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.delfood.delfood.Models.Plato;

public interface PlatoRepository extends JpaRepository<Plato, Long> {

    @Query("FROM Plato c WHERE c.name like :title")
    List<Plato> findByTitleContaining(@Param("title") String title);

    @Query("FROM Plato c WHERE c.precio <= :precio")
    List<Plato> findByFeeLessThan(@Param("precio") double fee);

    @Query("FROM Course c ORDER BY name ASC")
    public List<Plato> findAllSortByName();
}