package com.delfood.delfood.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.delfood.delfood.Models.Domicilio;

public interface DomicilioRepository extends JpaRepository<Domicilio, Long> {

    @Query("FROM Domicilio s WHERE s.Dirección LIKE :calle OR s.numero LIKE :name")
    public List<Domicilio> findByNameContaining(@Param("name") String name);

}

