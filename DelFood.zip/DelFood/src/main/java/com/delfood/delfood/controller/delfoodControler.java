package com.delfood.delfood.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.delfood.delfood.Models.Plato;
import com.delfood.delfood.repository.PlatoRepository;
import com.delfood.delfood.Models.Domicilio;
import com.service.DomicilioService;
import com.service.PlatoService;

import java.util.List;

@Controller
public class delfoodControler {
	@Autowired
    private PlatoService platoService;
    @Autowired
    private PlatoRepository platoRepository;

	public final DomicilioService domicilioService;

	public delfoodControler(PlatoService platoService, DomicilioService domicilioservice) {
		this.platoService = platoService;
		this.domicilioService = domicilioservice;
		this.platoRepository.findAllSortByName();
	}

	@RequestMapping("/platos")
	public String buscartodo(Model model) {
		List<Plato> platos = platoService.buscartodos();
		Domicilio domicilio = new Domicilio();
		model.addAttribute("Domicilio", domicilio);
		model.addAttribute("Platos", platos);
		return "listado";
	}

	@RequestMapping("/domicilio/{Id}")
	public String Domicilio(@PathVariable Long Id, Domicilio domicilio, Model model) {
		Domicilio domicilio2 = domicilioService.crearDomicilio(Id, domicilio);
		model.addAttribute("Domicilio", domicilio2);
		return "direccion";
	}
}